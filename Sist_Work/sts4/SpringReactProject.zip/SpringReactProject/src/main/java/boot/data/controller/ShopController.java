package boot.data.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin    //각각의 도메인을 연결시키는 것. 서버 2개있으면 반드시 crossOrigin 줘야함  
@RequestMapping("/shop")
public class ShopController {
	
	

	
}
